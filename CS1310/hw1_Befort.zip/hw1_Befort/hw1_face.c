/*
Hunter Befort
Sample program that prints a face with weird hat and eyebrows
*/

#include <stdio.h>

int main() {
    printf("   _____\n");
    printf("  /_____\\\n");
    printf(" /_______\\ \n");
    printf("// _   _ \\\\\n");
    printf(" | o   o | \n");
    printf(" |   ^   |\n");
    printf("  \\  -  / \n");
    printf("    ---  \n");
    
    return 0;
}
